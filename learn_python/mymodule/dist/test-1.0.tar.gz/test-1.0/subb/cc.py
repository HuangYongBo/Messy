def funccc():
	print("cc")
