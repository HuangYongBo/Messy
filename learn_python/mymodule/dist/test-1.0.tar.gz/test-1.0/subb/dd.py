def funcdd():
	print("dd")
