def funcb();
	print("bb")
