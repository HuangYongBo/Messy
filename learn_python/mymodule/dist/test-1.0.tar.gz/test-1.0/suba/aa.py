def funca():
	print("aa")
