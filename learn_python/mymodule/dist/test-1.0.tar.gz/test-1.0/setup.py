from distutils.core import setup

setup(name="test",version="1.0",description="my test module",author="huangyongbo",py_modules=['suba.aa','suba.bb','subb.cc','subb.dd'])
